package com.example;

import com.google.auto.service.AutoService;
import io.electrica.pipeline.java8.spi.Lambda;
import io.electrica.sdk.java8.api.Connection;
import io.electrica.sdk.java8.api.Connector;
import io.electrica.sdk.java8.api.Electrica;
import io.electrica.sdk.java8.echo.test.v1.EchoTestV1;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@AutoService(Lambda.class)
public class ExampleSimpleJobLambda implements Lambda {

    @Override
    public String getName() {
        return "SimpleJobLambda";
    }

    @Override
    public void onStopSignal() throws Exception {
        // Do nothing here because will make ping job and stop lambda immediately
    }

    /**
     * Just ping server and finish the job.
     */
    @Override
    public void doWork(Electrica electrica) throws Exception {
        Connector connector = electrica.connector(EchoTestV1.ERN);
        Connection connection = connector.defaultConnection();

        EchoTestV1 echoTest = new EchoTestV1(connection);
        echoTest.ping();
    }
}
