package com.example;

import com.google.auto.service.AutoService;
import io.electrica.pipeline.java8.spi.BackgroundProcessLambda;
import io.electrica.pipeline.java8.spi.Lambda;
import io.electrica.sdk.java8.api.Connection;
import io.electrica.sdk.java8.api.Connector;
import io.electrica.sdk.java8.api.Electrica;
import io.electrica.sdk.java8.echo.test.v1.EchoTestV1;
import lombok.extern.slf4j.Slf4j;

import java.util.UUID;

@Slf4j
@AutoService(Lambda.class)
public class ExampleBackgroundProcessLambda extends BackgroundProcessLambda {

    private Connection connection;
    private UUID listenerId;

    @Override
    public String getName() {
        return "BackgroundProcessLambda";
    }

    @Override
    public void initialize(Electrica electrica) throws Exception {
        super.initialize(electrica);

        Connector connector = electrica.connector(EchoTestV1.ERN);
        connection = connector.defaultConnection();
        EchoTestV1 echoTest = new EchoTestV1(connection);

        // Listen to messages from webhook
        listenerId = connection.addMessageListener(__ -> true, message -> {
            try {
                String payload = message.getPayload();
                return echoTest.echo(payload);
            } catch (Exception e) {
                log.error("Something went wrong handling message: " + message.getId(), e);
                return null;
            }
        });
    }

    @Override
    public void destroy(Electrica electrica) throws Exception {
        super.destroy(electrica);

        connection.removeMessageListener(listenerId);
    }
}
